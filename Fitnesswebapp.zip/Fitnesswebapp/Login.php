<!DOCTYPE html>
<html lang="en">
<title>Login.php</title>
<head>
<style>
    body,h1,h2,h3,h4,h5,h6 {font-family: "times"}
    .w3-bar,h1,button {font-family: "times", sans-serif}
    .fa-anchor,.fa-coffee {font-size:100px}
</style>
</head>

<body>

<!-- Allow users to enter in their login details --> 

<form action="Login.php" method="post">
    Username: <input type="text" name="LoginNameInput"><br>
    Password: <input type="text" name="LoginPasswordInput"><br>
    <input type="submit">


  
</form>

</body>
 

<?php 

// Validate the login details 

// Since database is not connected yet, Ill have to give in
// some sample data in the mean time. -->

$Username = $_POST["LoginNameInput"];
$Password = $_POST["LoginPasswordInput"];

// Add in validation using the SQL database in the future.
if ($Username == "admin" && $Password == "admin" ){
       echo"<script language ='javascript'>window.location = 'dashboard.html';</script>";
    echo" Working!";
}

?> 


