<!DOCTYPE html>

<!-- 

    Author : Yonis Ismail

    Title : Signup

    Created : 11/11/2021

    Last Modified : 12/11/2021 

    Project : Fitness Web Application

    Task : Create signup page when database is complete.


-->
<html lang="en">
<title>Signup.php</title>
<head>
<style>
    body,h1,h2,h3,h4,h5,h6 {font-family: "times"}
    .w3-bar,h1,button {font-family: "times", sans-serif}
    .fa-anchor,.fa-coffee {font-size:100px}

</style>
    <h1> Welcome to the signup page. </h1>
    <br><p> Please input your username and your password to create an account. </p>

</head>

<body>

<!-- Create form for user to input data --> 

<form action="signup.php" method="post">
    Username: <input type="text" name="SignupNameInput"><br>
    Password: <input type="text" name="SignupPasswordInput"><br>
    <input type="submit">
  
</form>
</body>
</html>

<?php

///////////////////// PHP start

// recieve user input from webpage

    $Username = $_POST["SignupNameInput"];
    $Password = $_POST["SignupPasswordInput"];

// Send to database
//////////////////////////////////////////////////////////////
///////////////Complete when database is finish///////////////
//////////////////////////////////////////////////////////////


// Redirect back to login page
echo"<script language ='javascript'>window.location = 'Login.php';</script>";
echo" Working!";
?>
